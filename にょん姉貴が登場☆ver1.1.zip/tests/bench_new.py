"""新方式(今回の FrameStore/Animation/Sprites をそのまま使用)。全アニメを一通り再生 → サイズ変更の連続。"""
import sys, time, random
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from harness import *
app = load_app(); from pathlib import Path
app.ASSET_DIR = Path(__import__("os").environ["NYN_ASSETS"])
scale0 = int(sys.argv[1]); base = rss_mb(); random.seed(7)
spr = app.Sprites(scale0, dict(app.DEFAULTS), backend=PilBackend())
st = spr.store; miss = [0, 0]
_get = st.get
def counting_get(*a, **k):
    r = _get(*a, **k); miss[0] += 1; miss[1] += (r is None); return r
st.get = counting_get
last = {"r": 0.0, "lat": 0.0}
def row(tag):
    s = st.stats(); print(f"  {tag:30s} 未用意={last['r']*100:4.1f}% 最大待ち={last['lat']:4.1f}ms RSS増加={rss_mb()-base:6.0f}MB  圧縮層={s['comp_MB']:6.1f}MB({s['comp_n']:4d}コマ) ホット層={s['hot_MB']:5.1f}MB  破棄={s['evicted']:4d} 失敗={s['failed']}", flush=True)
t0 = time.time(); spr.begin_startup()
while spr.store.startup_state()[0] < spr.store.startup_state()[1]: time.sleep(0.01)
print(f"NEW scale={scale0}%  起動必須コマ準備完了まで {time.time()-t0:.2f}s (PIL/1コア)", flush=True)
row("起動直後(必須コマのみ)")
def play(name, secs, flips=False):
    a = spr.anims[name]; t0 = time.time(); facing = False; miss[0] = miss[1] = 0; mx = 0.0
    while time.time() - t0 < secs:
        if flips and int((time.time()-t0)/2) % 2: facing = True
        else: facing = False
        s0 = time.perf_counter(); a.frame(time.time() - t0, facing, 1.0); mx = max(mx, (time.perf_counter()-s0)*1000); time.sleep(1/60)
    last["r"] = miss[1] / max(1, miss[0]); last["lat"] = mx
    return last["r"]
for name, secs, fl in [("start",1.2,0),("idle",14,1),("walk",5,1),("grabbed",2,0),("react",1.2,0),("land",1.2,0),("exit",1.2,0),("sleep",25,0)]:
    r = play(name, secs, fl); row(f"再生後: {name}")
print("  -- サイズ変更の連続 --")
for sc in [200, 400, 100, 300, 50, 400, 100]:
    t0 = time.time(); spr.set_scale(sc); ms = (time.time()-t0)*1000
    r = play("idle", 4, 1); row(f"→{sc}% (set_scale {ms:.0f}ms)")
with open("/proc/self/status") as f:
    peak = [l for l in f if l.startswith("VmHWM")][0].split()[1]
print(f"  ピークRSS(Python基礎込み)={int(peak)/1024:.0f}MB  基礎={base:.0f}MB")
spr.shutdown()
