"""サイズ変更直後の滑らかさ: 1秒あたりに『別のコマが表示された回数』(理想=24)。"""
import sys, time, random
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from harness import *
app = load_app(); from pathlib import Path
app.ASSET_DIR = Path(__import__("os").environ["NYN_ASSETS"])
spr = app.Sprites(100, dict(app.DEFAULTS), backend=PilBackend()); st = spr.store
spr.begin_startup()
while st.startup_state()[0] < st.startup_state()[1]: time.sleep(0.01)
a = spr.anims["idle"]; t_anim = time.time()
def run(label, secs):
    global t_anim
    t0 = time.time(); seen = []; none = 0; sync = True
    while time.time() - t0 < secs:
        img = a.frame(time.time() - t_anim, False, 1.0, block=sync); sync = False
        none += img is None
        if img is not None and (not seen or seen[-1][1] is not img): seen.append((time.time() - t0, img))
        time.sleep(1/60)
    # 1秒ごとの表示更新回数
    per = [sum(1 for t, _ in seen if k <= t < k + 1) for k in range(int(secs))]
    print(f"  {label:14s} 更新/秒: {per}  (理想=24)  描画なし={none}", flush=True)
run("100%(定常)", 4)
for sc in [200, 400, 300]:
    spr.set_scale(sc); run(f"→{sc}%直後", 8)
spr.shutdown()
