"""旧方式の再現: 全コマを表示サイズに縮小して常時保持(元コードの Animation.scaled と同じ保持量)。"""
import sys, time, glob, re
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from harness import *
scale = int(sys.argv[1]); A = __import__("os").environ["NYN_ASSETS"]
base = rss_mb(); be = PilBackend()
H = round(160 * scale / 100); W = round(1280 * H / 720)
held = []; t0 = time.time()
for st in ["idle","walk","sleep","grabbed","react","land","getup","start","exit"]:
    fs = sorted(glob.glob(f"{A}/{st}/*.png"), key=lambda p: [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", p)])
    if not fs: continue
    w0, h0 = be.image_size(fs[0]); f = min(W / w0, H / h0)
    for p in fs:
        im = be.decode(p); held.append(be.scale(im, max(1, round(im.size[0]*f)), max(1, round(im.size[1]*f))))
print(f"OLD scale={scale}% frames={len(held)} load_time={time.time()-t0:.1f}s  RSS増加={rss_mb()-base:.0f}MB  保持画像={sum(len(x.buf) for x in held)/1048576:.0f}MB")
