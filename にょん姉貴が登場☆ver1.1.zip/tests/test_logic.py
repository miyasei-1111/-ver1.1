import sys, time, os, shutil, tempfile, threading
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
import harness
from harness import *
app = load_app()
import numpy as np
from PIL import Image
P = []
def check(name, cond, extra=""):
    P.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else ""))

# ---- T1: ByteLRU ----
l = app.ByteLRU(100)
for i in range(10): l.put(i, i, 30)
check("T1 LRU 上限を超えない", l.total <= 100 and len(l) == 3 and l.evicted == 7, f"total={l.total} n={len(l)}")
l.get(7); l.put(99, 99, 30)
check("T1 LRU 最近使った物が残る", 7 in l and 8 not in l)
l.put("big", 1, 10**6)
check("T1 LRU 単独の巨大要素は許容(空にはならない)", "big" in l and len(l) == 1)

# ---- 合成素材(小さいPNG)を使う試験用の assets ----
def make_assets(root, counts, size=(160, 90), special=None):
    for st, n in counts.items():
        d = root / st; d.mkdir(parents=True, exist_ok=True)
        for i in range(n):
            a = np.zeros((size[1], size[0], 4), np.uint8)
            a[10:80, 20:140] = (200, 120 + i % 100, 50, 255)
            a[30:50, 30 + (i % 50):60 + (i % 50)] = (20, 20, 20, 255)
            Image.fromarray(a, "RGBA").save(d / f"{i+1:03d}.png")

tmp = Path(tempfile.mkdtemp())
make_assets(tmp, {"idle": 40, "walk": 8, "start": 10, "react": 6, "land": 6, "grabbed": 6, "exit": 6, "sleep": 60})
app.ASSET_DIR = tmp
be = PilBackend()

# ---- T2: 圧縮ラウンドトリップ(ロスレス)と反転 ----
im = be.scale(Image.open(tmp / "idle/001.png").convert("RGBA"), 80, 45)
ok = be.unpack(be.pack(im)[0]).buf == im.buf
check("T2 圧縮→展開が完全一致(ロスレス)", ok)
m = be.mirror(im)
a = np.frombuffer(im.buf, np.uint8).reshape(45, 80, 4)
check("T2 左右反転が正しい", np.array_equal(np.frombuffer(m.buf, np.uint8).reshape(45, 80, 4), a[:, ::-1]))

# ---- T3: 起動: 必須コマだけで準備完了 / 進捗 ----
prog = []
sig = app.StoreSignals(); sig.progress.connect(lambda d, t: prog.append((d, t)))
spr = app.Sprites(100, dict(app.DEFAULTS), backend=be, signals=sig)
items = spr.startup_items()
t0 = time.time(); spr.begin_startup()
while True:
    d, t = spr.store.startup_state()
    if d >= t or time.time() - t0 > 20: break
    time.sleep(0.01)
check("T3 起動必須コマ(idle先頭+start)が揃う", d == t == len(items), f"{d}/{t} 件 {time.time()-t0:.2f}s")
check("T3 進捗Signalが単調増加で総数に到達", prog and prog[-1][1] == t and all(prog[i][0] <= prog[i+1][0] for i in range(len(prog)-1)), f"最終={prog[-1] if prog else None}")
check("T3 起動直後に全コマは読んでいない(遅延読み込み)", spr.store.stats()["comp_n"] < 40 + 8 + 10 + 6 * 4 + 60)

spr.shutdown()   # T3用のストアを止める(後のスレッド残り確認を正確にするため)

# ---- T4: 再生: 未用意コマでも止まらず代用される ----
spr2 = app.Sprites(100, dict(app.DEFAULTS), backend=PilBackend())   # まだ何も読んでいない
a_walk = spr2.anims["walk"]
img = a_walk.frame(0.0, False, 1.0)       # 何も無い → None のはず(last_image も無い)
check("T4 何も用意できていなくても例外にならない", img is None)
spr2.store.start()
lat = []; none_cnt = 0; t0 = time.time()
while time.time() - t0 < 4.0:
    s = time.perf_counter(); im = spr2.anims["idle"].frame(time.time() - t0, False, 1.0); lat.append((time.perf_counter() - s) * 1000)
    none_cnt += im is None; time.sleep(1/60)
check("T4 4秒再生でGUI側の最大待ち時間が小さい", max(lat) < 25, f"max={max(lat):.1f}ms mean={sum(lat)/len(lat):.2f}ms 未表示={none_cnt}")
spr2.shutdown()

# ---- T5: 失敗コマ(壊れたPNG・欠損): 落ちない・再試行しない・ログ1回 ----
tmp2 = Path(tempfile.mkdtemp()); make_assets(tmp2, {"idle": 10, "walk": 6})
(tmp2 / "walk/003.png").write_bytes(b"not a png")           # 壊れたファイル
os.remove(tmp2 / "idle/005.png")                              # 起動後に消えた想定は下で
app.ASSET_DIR = tmp2
be2 = PilBackend(); spr3 = app.Sprites(100, dict(app.DEFAULTS), backend=be2)
spr3.begin_startup(); time.sleep(1.0)
w = spr3.anims["walk"]
res = [w.frame(i / 24, False, 1.0, block=True) for i in range(6) for _ in range(3)]   # 同じコマを3回ずつ要求
check("T5 壊れたコマがあっても例外なし", True)
bad = str(tmp2 / "walk/003.png")
check("T5 壊れたコマは1回しか読み込もうとしない(無限再試行なし)", be2.decode_calls.get(bad, 0) <= 1, f"試行={be2.decode_calls.get(bad)}")
check("T5 failed に記録される", ("walk", 2) in spr3.store._failed)
spr3.shutdown()
app.ASSET_DIR = tmp

# ---- T6: 読み込み途中の終了 ----
spr4 = app.Sprites(300, dict(app.DEFAULTS), backend=PilBackend())
spr4.begin_startup(); t0 = time.time(); spr4.shutdown()
check("T6 読み込み中に shutdown してもすぐ終わる", time.time() - t0 < 3, f"{time.time()-t0:.2f}s")
spr4.shutdown(); check("T6 shutdown の二重呼び出しが安全", True)
alive = [t for t in threading.enumerate() if t.name.startswith("frame-worker") and t.is_alive()]
check("T6 ワーカースレッドが残らない", not alive, f"残={len(alive)}")

# ---- T7: サイズ変更の連打: 世代で古い要求を無効化 / キャッシュに古いサイズが混ざらない ----
spr5 = app.Sprites(100, dict(app.DEFAULTS), backend=PilBackend()); spr5.begin_startup()
import random; random.seed(1); errs = []
def player():
    t0 = time.time()
    while time.time() - t0 < 6:
        try: spr5.anims["idle"].frame(time.time() - t0, random.random() < .5, 1.0, block=False)
        except Exception as e: errs.append(e)
        time.sleep(1/60)
th = threading.Thread(target=player); th.start()
gens = []
for i in range(30):
    sc = random.choice([30, 50, 100, 200, 300, 400]); spr5.set_scale(sc); gens.append(spr5.store.gen); time.sleep(random.uniform(0.01, 0.15))
th.join(); time.sleep(0.5)
st = spr5.store
with st.cv:
    sizes = {(v.w, v.h) for v, n in st.hot._od.values()}
    csz = {(p[1], p[2]) for c in st._comp.values() for (p, n) in c._od.values()}
check("T7 サイズ連打中に例外なし", not errs, f"errs={errs[:1]}")
check("T7 世代が変更回数ぶん進む", st.gen >= 31, f"gen={st.gen}")
exp_w = None
fits = all(h <= st.H + 1 and w <= st.W + 1 for (w, h) in sizes | csz)
check("T7 キャッシュに古いサイズの画像が混ざらない", fits, f"現在={st.W}x{st.H} 実在={sorted(sizes|csz)[:4]}")
check("T7 キャッシュが上限内", st.stats()["comp_MB"] <= 160 + 96 and st.stats()["hot_MB"] <= max(16, 20 * st.W * st.H * 4 / app.MB) + 4, str(st.stats()))
spr5.shutdown()

print("\n結果:", sum(P), "/", len(P), "PASS")
sys.exit(0 if all(P) else 1)
