import sys, time, os, tempfile, threading
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from harness import *
app = load_app()
import numpy as np
from PIL import Image
P = []
def check(name, cond, extra=""):
    P.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else ""))

def make_assets(root, counts, size=(160, 90)):
    for st, n in counts.items():
        d = root / st; d.mkdir(parents=True, exist_ok=True)
        for i in range(n):
            a = np.zeros((size[1], size[0], 4), np.uint8); a[10:80, 20:140] = (200, 120 + i % 100, 50, 255)
            Image.fromarray(a, "RGBA").save(d / f"{i+1:03d}.png")
tmp = Path(tempfile.mkdtemp()); make_assets(tmp, {"idle": 30, "walk": 10, "react": 8, "start": 5})
app.ASSET_DIR = tmp

# T8: 未用意の walk は idle で代用(例外なし・None にならない)
be = PilBackend(); spr = app.Sprites(100, dict(app.DEFAULTS), backend=be); spr.begin_startup()
while spr.store.startup_state()[0] < spr.store.startup_state()[1]: time.sleep(0.01)
spr.store._warm_q.clear()                                   # ウォームアップを止めて「未用意」を再現
img = spr.anims["walk"].frame(0.0, False, 1.0)
check("T8 未用意の walk は idle の絵で代用される", img is not None and (img.w, img.h) == (spr.W, spr.H) or img is not None)
# 素材が無い状態(getup)は idle を共用
g = spr.anims["getup"]; check("T8 素材なし状態は idle 共用(fallback=True)", g.fallback and g.frame(0.2, False, 1.0) is not None)

# T9: 非ループ(react)は最終コマで止まる・先読みが先頭へ回り込まない
r = spr.anims["react"]; time.sleep(0.5)
last = [r.frame(t, False, 1.0) for t in (10.0, 20.0)]
check("T9 非ループは最後のコマで止まる(同じコマ)", last[0] is last[1] or (last[0] is not None and last[0].buf == last[1].buf))
with spr.store.cv:
    pend_keys = list(spr.store._hot_pending)
check("T9 非ループの先読みは範囲外・先頭へ回り込まない", all(k[1] < 8 for k in pend_keys))
spr.shutdown()

# T10: 世代競合 — 遅い読み込みの最中にサイズ変更しても古いサイズが混ざらない
class SlowBackend(PilBackend):
    def decode(self, p): time.sleep(0.05); return super().decode(p)
spr = app.Sprites(100, dict(app.DEFAULTS), backend=SlowBackend()); spr.store.start()
spr.anims["idle"].frame(0.0, False, 1.0, block=False)
time.sleep(0.12); spr.set_scale(300); spr.anims["idle"].frame(0.0, False, 1.0); time.sleep(0.8)
st = spr.store
with st.cv:
    szs = {(v.w, v.h) for v, n in st.hot._od.values()} | {(p[1], p[2]) for c in st._comp.values() for (p, n) in c._od.values()}
check("T10 遅い読み込み中のサイズ変更で古い世代の結果が捨てられる", szs == {(st.W, st.H)} or szs <= {(st.W, st.H)}, f"現在={st.W}x{st.H} 実在={szs}")
spr.shutdown()

# T11: メモリ不足(MemoryError)注入 — 落ちない・失敗として記録・再試行しない
class OOM(PilBackend):
    def scale(self, img, w, h):
        self.n = getattr(self, "n", 0) + 1
        if self.n % 3 == 0: raise MemoryError("simulated")
        return super().scale(img, w, h)
spr = app.Sprites(100, dict(app.DEFAULTS), backend=OOM()); spr.begin_startup(); time.sleep(1.5)
errs = []
try:
    for i in range(40): spr.anims["idle"].frame(i / 24, False, 1.0)
except Exception as e: errs.append(e)
check("T11 MemoryError が起きても例外を外へ出さない", not errs and spr.store.stats()["failed"] > 0, f"失敗記録={spr.store.stats()['failed']}")
alive = [w for w in spr.store._workers if w._t.is_alive()]
check("T11 ワーカースレッドは生きている(スレッドが死なない)", len(alive) == spr.store._nworkers)
spr.shutdown()

# T12: 実効fps指定でも先読みが範囲内
spr = app.Sprites(100, dict(app.DEFAULTS), backend=PilBackend()); spr.begin_startup(); time.sleep(0.5)
x = spr.anims["idle"].frame(0.0, True, 3.0)      # 3倍速・左右反転
check("T12 3倍速+反転でも画像が返る", x is not None)
spr.shutdown()

print("\n結果:", sum(P), "/", len(P), "PASS"); sys.exit(0 if all(P) else 1)
