import sys, time, ctypes, gc
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from harness import *
app = load_app(); from pathlib import Path
app.ASSET_DIR = Path(__import__("os").environ["NYN_ASSETS"])
base = rss_mb(); spr = app.Sprites(400, dict(app.DEFAULTS), backend=PilBackend()); st = spr.store; spr.begin_startup()
a = spr.anims["idle"]; t0 = time.time()
while time.time() - t0 < 12: a.frame(time.time() - t0, False, 1.0); time.sleep(1/60)
s = st.stats(); print(f"400%で12秒再生後   RSS増加={rss_mb()-base:5.0f}MB  圧縮層={s['comp_MB']}MB ホット層={s['hot_MB']}MB")
spr.set_scale(50); time.sleep(0.2)
with st.cv: st._warm_q.clear()
t0 = time.time()
while time.time() - t0 < 6: a.frame(time.time() - t0, False, 1.0); time.sleep(1/60)
s = st.stats(); print(f"50%へ縮小後        RSS増加={rss_mb()-base:5.0f}MB  圧縮層={s['comp_MB']}MB ホット層={s['hot_MB']}MB  ← 実データは約{s['comp_MB']+s['hot_MB']:.0f}MB")
gc.collect(); ctypes.CDLL("libc.so.6").malloc_trim(0)
print(f"malloc_trim(解放済み領域をOSへ返す)後  RSS増加={rss_mb()-base:5.0f}MB")
spr.shutdown()
