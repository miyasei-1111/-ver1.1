"""PySide6 が無い環境で nyn_desktopalfa4.py の中核ロジックを動かすための代役(shim)と、PIL版の画像バックエンド。
Qt の画像関数(QImage 等)だけを差し替え、FrameStore / Animation / Sprites / ByteLRU はアプリ本体のコードをそのまま使う。"""
import sys, types, threading, zlib, importlib.util, os
from pathlib import Path
import numpy as np
from PIL import Image

# ---------------- PySide6 の代役 ----------------
class _Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n): return _Stub()
    def __call__(self, *a, **k): return _Stub()

class _Bound:
    def __init__(self): self.slots = []
    def connect(self, fn, type=None): self.slots.append(fn)
    def emit(self, *a):
        for s in list(self.slots): s(*a)

class Signal:
    def __init__(self, *types): pass
    def __set_name__(self, owner, name): self.name = "_sig_" + name
    def __get__(self, obj, owner=None):
        if obj is None: return self
        if self.name not in obj.__dict__: obj.__dict__[self.name] = _Bound()
        return obj.__dict__[self.name]

class QThread:
    class Priority: LowPriority = 1
    def __init__(self, *a): self._t = None; self._name = ""
    def setObjectName(self, n): self._name = n
    def start(self, prio=None):
        self._t = threading.Thread(target=self.run, name=self._name, daemon=True); self._t.start()
    def wait(self, ms=None):
        self._t.join(ms / 1000 if ms else None); return not self._t.is_alive()
    def terminate(self): pass

class QObject:
    def __init__(self, *a, **k): pass

class _Enum:
    def __getattr__(self, n): return _Enum()

def install_shim():
    names = {
        "PySide6.QtCore": dict(Qt=_Enum(), QObject=QObject, QThread=QThread, QTimer=_Stub,
                               QUrl=_Stub, QPointF=_Stub, QRect=_Stub, QPoint=_Stub, Signal=Signal),
        "PySide6.QtGui": {n: type(n, (_Stub,), {}) for n in
                          ["QColor", "QFont", "QGuiApplication", "QImage", "QImageReader", "QPainter", "QPen", "QTransform"]},
        "PySide6.QtMultimedia": {n: type(n, (_Stub,), {}) for n in ["QAudioOutput", "QMediaPlayer"]},
        "PySide6.QtWidgets": {n: type(n, (_Stub,), {}) for n in
                              ["QApplication", "QCheckBox", "QComboBox", "QDialog", "QDialogButtonBox", "QFormLayout",
                               "QHBoxLayout", "QLabel", "QMenu", "QProgressBar", "QSlider", "QVBoxLayout", "QWidget"]},
    }
    root = types.ModuleType("PySide6"); sys.modules["PySide6"] = root
    for mod, attrs in names.items():
        m = types.ModuleType(mod); m.__dict__.update(attrs); sys.modules[mod] = m
        setattr(root, mod.split(".")[1], m)

def load_app():
    """mascot パッケージを(PySide6 の代役つきで)読み込み、テストで使う名前をまとめて返す。
    ASSET_DIR は呼び出し時に Sprites(asset_dir=...) へ渡される(テストが差し替えられる)。"""
    import functools
    from types import SimpleNamespace
    root = os.environ.get("NYN_ROOT") or str(Path(__file__).resolve().parent.parent)
    if root not in sys.path: sys.path.insert(0, root)
    install_shim()
    from mascot import config
    from mascot.imaging.lru import ByteLRU
    from mascot.imaging.store import FrameStore, StoreSignals
    from mascot.animation.sprites import Sprites as _Sprites
    ns = SimpleNamespace(ByteLRU=ByteLRU, FrameStore=FrameStore, StoreSignals=StoreSignals,
                         DEFAULTS=config.DEFAULTS, MB=config.MB, ASSET_DIR=config.ASSET_DIR)
    def Sprites(*a, **k):
        k.setdefault("asset_dir", ns.ASSET_DIR)
        return _Sprites(*a, **k)
    ns.Sprites = Sprites
    return ns

# ---------------- PIL 版の画像バックエンド(QtImageBackend と同じ呼び出し口) ----------------
class PImg:
    __slots__ = ("w", "h", "buf")
    def __init__(self, w, h, buf): self.w, self.h, self.buf = w, h, buf

class PilBackend:
    def __init__(self): self.decode_calls = {}
    def image_size(self, path):
        try:
            with Image.open(path) as im: return im.size
        except Exception: return None
    def decode(self, path):
        self.decode_calls[str(path)] = self.decode_calls.get(str(path), 0) + 1
        try: return Image.open(path).convert("RGBA")
        except Exception: return None
    def size_of(self, img): return img.size
    def scale(self, img, w, h):
        return PImg(w, h, img.resize((w, h), Image.BILINEAR).tobytes())
    def nbytes(self, img): return len(img.buf)
    def mirror(self, img):
        a = np.frombuffer(img.buf, np.uint8).reshape(img.h, img.w, 4)[:, ::-1]
        return PImg(img.w, img.h, a.tobytes())
    def pack(self, img):
        d = zlib.compress(img.buf, 1); return ("z", img.w, img.h, d), len(d) + 64
    def unpack(self, p):
        return PImg(p[1], p[2], zlib.decompress(p[3]))

def rss_mb():
    with open("/proc/self/status") as f:
        for l in f:
            if l.startswith("VmRSS:"): return int(l.split()[1]) / 1024

def assets_dir():
    """実素材の assets フォルダ(環境変数 NYN_ASSETS で指定)"""
    return Path(os.environ["NYN_ASSETS"])
