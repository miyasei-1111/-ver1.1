検証スクリプト(PySide6 なしで、キャッシュ・スレッド・先読みの中核ロジックを検証します)
  ・Qt の画像処理だけを PIL 版に差し替え、mascot パッケージの FrameStore / Animation / Sprites /
    ByteLRU は実物をそのまま使います。Qt 部分(QImage の圧縮/展開、ウィンドウ、描画、音声)は検証していません。
準備: pip install pillow numpy
      環境変数 NYN_ASSETS に、素材の assets フォルダを指定(bench_*.py だけ必要)
実行: python tests/test_logic.py / python tests/test_logic2.py   … 単体テスト(合成素材。素材不要)
      python tests/bench_old.py 100 / python tests/bench_new.py 100  … 旧方式の再現 / 新方式のメモリ比較(実素材)
      python tests/bench_resize.py                                  … サイズ変更直後の滑らかさ
      python tests/bench_trim.py                                    … 縮小後のメモリが残る原因の切り分け(Linux用)
      python tools/check_architecture.py                            … 依存関係の検査
