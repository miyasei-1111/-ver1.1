# -*- coding: utf-8 -*-
"""
依存関係の検査(PySide6 不要。ソースを読むだけ)。  実行: python tools/check_architecture.py

  1. mascot パッケージ内の import に循環が無いこと(関数の中の遅延 import も含めて検査)
  2. パッケージごとの「依存してよい先」を守っていること(下の ALLOWED)
  3. __init__.py が mascot 内の何かを import していないこと(循環の温床になるため)

新しいパッケージや依存を追加するときは、ALLOWED を先に更新してから実装する。
"""
import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PKG = ROOT / "mascot"

# パッケージ → 依存してよいパッケージ(自分自身はいつでも可)。上位が下位へ向かう一方向のみ。
ALLOWED = {
    "config":      set(),
    "diagnostics": {"config"},
    "system":      {"config"},
    "imaging":     {"config", "diagnostics"},
    "audio":       {"config", "diagnostics"},
    "animation":   {"config", "diagnostics", "imaging"},
    "ui":          {"config", "diagnostics", "system"},     # animation / audio / imaging には依存しない(注入される)
    "startup":     {"config", "diagnostics", "system", "imaging", "audio", "animation", "ui"},
    "app":         {"config", "diagnostics", "startup"},
}


def module_name(path):
    rel = path.relative_to(ROOT).with_suffix("")
    parts = list(rel.parts)
    if parts[-1] == "__init__":
        parts.pop()
    return ".".join(parts)


def top_package(mod):
    parts = mod.split(".")
    return parts[1] if len(parts) > 1 else ""


def internal_imports(path, mod):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    found = set()
    for n in ast.walk(tree):                       # 関数の中の import も拾う
        if isinstance(n, ast.Import):
            found |= {a.name for a in n.names if a.name.split(".")[0] == "mascot"}
        elif isinstance(n, ast.ImportFrom):
            if n.level:                            # 相対 import は使わない方針(依存が見えにくくなる)
                found.add("<相対import>")
            elif n.module and n.module.split(".")[0] == "mascot":
                found.add(n.module)
                for a in n.names:                  # from mascot.x import y の y がモジュールの場合
                    cand = f"{n.module}.{a.name}"
                    if (ROOT / (cand.replace(".", "/") + ".py")).exists():
                        found.add(cand)
    return found


def main():
    errors = []
    graph = {}
    files = sorted(PKG.rglob("*.py"))
    for f in files:
        mod = module_name(f)
        deps = internal_imports(f, mod)
        graph[mod] = deps
        if f.name == "__init__.py" and deps:
            errors.append(f"{mod}: __init__.py が mascot 内を import している: {sorted(deps)}")
        if f.name == "__main__.py" or mod in ("mascot", ):
            continue
        pkg = top_package(mod)
        for d in deps:
            if d == "<相対import>":
                errors.append(f"{mod}: 相対 import は使わない(絶対 import にする)")
                continue
            dp = top_package(d)
            if dp != pkg and dp not in ALLOWED.get(pkg, set()):
                errors.append(f"{mod} → {d}: 禁止された依存({pkg} は {dp} に依存できない)")

    # 循環検出(モジュール単位)
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {m: WHITE for m in graph}

    def dfs(m, stack):
        color[m] = GRAY
        for d in sorted(graph.get(m, ())):
            if d not in graph:
                continue
            if color[d] == GRAY:
                errors.append("循環インポート: " + " → ".join(stack[stack.index(d):] + [d]) if d in stack else f"循環: {m} → {d}")
            elif color[d] == WHITE:
                dfs(d, stack + [d])
        color[m] = BLACK

    for m in sorted(graph):
        if color[m] == WHITE:
            dfs(m, [m])

    n_edges = sum(len(v) for v in graph.values())
    if errors:
        print("NG: アーキテクチャ違反があります")
        for e in errors:
            print("  -", e)
        return 1
    print(f"OK: {len(graph)} モジュール / {n_edges} 依存。循環なし、層の規則に違反なし。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
